export interface CreditCard {
  name: string;
  length: number[];
  prefixes: number[];
  checkdigit: boolean;
}
